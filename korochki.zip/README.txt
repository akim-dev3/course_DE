Корочки.есть — портал записи на курсы ДПО
Демонстрационный экзамен, 09.02.07

Стек: PHP 8 (mysqli, prepared statements, без классов — обычные функции), MySQL, Bootstrap 5, чистый JS

=== Установка ===
1. Скопировать папку в htdocs (XAMPP) или domains (OpenServer)
2. Создать базу: phpMyAdmin -> Импорт -> sql/korochki_est.sql
   (или mysql -u root korochki_est < sql/korochki_est.sql)
3. При необходимости поправить доступ к БД в init.php (по умолчанию root без пароля)
4. Открыть http://localhost/korochki/

=== Вход ===
Админ:        Admin / KorokNET
Пользователь: регистрация через форму на сайте

=== Структура ===
init.php              - подключение к БД, общие данные ($courses, $payments, $statuses)
includes/db.php       - работа с БД: isLoginTaken, registerUser, attemptLogin,
                        createRequest, getRequestsByUser, addReview,
                        changeRequestStatus, getRequestsForAdmin, countRequestsForAdmin
includes/             - шапка, подвал, валидаторы
assets/               - css (свои стили + bootstrap), js (слайдер, маски), картинки
sql/                  - дамп базы

=== Модули ===
М1 - регистрация, авторизация, заявки, кабинет, админка, проверки на бэке
М2 - адаптив, слайдер, select курса/оплаты, ошибки на форме, фильтр+пагинация в админке
М3 - вёрстка на Bootstrap, анимации карточек, индексы в БД под фильтрацию

ER-диаграмму строить в phpMyAdmin -> Дизайнер (связь user_id -> users.id уже в дампе)
